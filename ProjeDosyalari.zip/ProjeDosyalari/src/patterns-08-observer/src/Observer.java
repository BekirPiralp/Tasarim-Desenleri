public interface Observer {
	public void Update();
}
