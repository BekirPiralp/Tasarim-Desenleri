public abstract class Aggregate {
	public abstract Iterator createIterator(); 
}
