public interface State {
	void Handle(); 
}
