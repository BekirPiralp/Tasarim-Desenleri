
public interface Command {
	void Execute();
}
