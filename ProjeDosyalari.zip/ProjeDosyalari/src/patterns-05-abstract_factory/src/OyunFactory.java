public abstract class OyunFactory {
	public abstract SoyutOyun yeniOyun();
	public abstract SoyutKapi kapiYarat(); 
	public abstract SoyutOda odaYarat();
}
