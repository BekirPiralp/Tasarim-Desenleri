public abstract class SoyutOyun {
	public abstract void odaEkle(SoyutOda a);
	public abstract void oyunCalistir();
}
