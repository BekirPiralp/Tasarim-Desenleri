public abstract class SoyutKapi {
	public abstract boolean kapiAc(); 
	public abstract void kapiKapat(); 
}
