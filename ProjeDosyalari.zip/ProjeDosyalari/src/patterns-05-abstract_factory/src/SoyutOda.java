public abstract class SoyutOda {
	public abstract void kapiEkle(SoyutKapi k);
	public abstract boolean kapiAc();
}
