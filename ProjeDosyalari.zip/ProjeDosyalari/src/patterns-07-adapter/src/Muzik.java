public class Muzik {
	private String isim;
	public Muzik(String i) {
		isim = i;
	}
	public void MP3Oynat() {
		System.out.println(isim + " çalınıyor.");
	}
}
