public abstract class Araba {
	public int maksHiz;
	public int anlikHiz;
	
	public abstract int maksHizAl();
	public abstract String marka();
	public abstract void hiziBelirle(int s);
}
