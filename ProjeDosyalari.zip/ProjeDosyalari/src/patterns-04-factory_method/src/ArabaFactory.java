
public abstract class ArabaFactory {
	public abstract Araba ArabaUret();
}
