public abstract class Grafik {
	protected String dosyaYolu;
	public abstract void Ciz();
	public abstract void grafikBilgisi();
}
