public interface Icerik {
	void Operation();
	void Add(Icerik i);
	void Remove(Icerik i);
	Icerik GetChild(int i);
}
